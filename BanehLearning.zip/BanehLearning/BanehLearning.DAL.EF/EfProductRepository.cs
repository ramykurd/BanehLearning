﻿using System;
using BanehLearning.Core.Contracts;
using BanehLearning.Core.Entities;
using BanehLearning.DAL.EF.DB;
namespace BanehLearning.DAL.EF
{
    public class EfProductRepository : ProductRepository
    {
        public void Add(Product prodct)
        {
            throw new NotImplementedException();
        }

        public Product FindByName(string name)
        {
            throw new NotImplementedException();
        }
    }
}
