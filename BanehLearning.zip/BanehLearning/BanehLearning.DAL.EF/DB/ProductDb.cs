﻿using BanehLearning.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BanehLearning.DAL.EF.DB
{
    public class ProductDb:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;initial catalog=BanehLearning; integrated security=true");
            base.OnConfiguring(optionsBuilder);
        }
        public DbSet<Product> products { get; set; }

    }
}
