﻿using BanehLearning.Core.Contracts;
using BanehLearning.Core.Entities;
using System;

namespace BanehLearning.Core.ApplicationServices
{
    public class CategoryService
    {
        private readonly CategoryRepository _categoryrepository;

        public CategoryService (CategoryRepository categoryrepository)
        {
            this._categoryrepository = categoryrepository;
        }
        void AddCategory(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                var categoryIndb = _categoryrepository.FindByName(name);
                if (categoryIndb == null || categoryIndb.Id < 1)
                {
                    Category category = new Category
                    {
                        Name = name
                    };
                    _categoryrepository.Add(category);
                }
            }
        }
    }
}
