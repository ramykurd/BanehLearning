﻿using BanehLearning.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BanehLearning.Core.Contracts
{
    public interface CategoryRepository
    {
        void Add(Category category);

        Category FindByName(string name);
       
    }
}
