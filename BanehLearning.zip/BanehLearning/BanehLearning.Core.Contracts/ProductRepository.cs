﻿using BanehLearning.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BanehLearning.Core.Contracts
{
    public interface ProductRepository
    {
        void Add(Product prodct);
        Product FindByName(string name);
    }
}
