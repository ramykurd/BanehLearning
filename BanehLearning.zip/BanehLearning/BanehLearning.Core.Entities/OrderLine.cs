﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BanehLearning.Core.Entities
{
    public class OrderLine
    {
    }
}
